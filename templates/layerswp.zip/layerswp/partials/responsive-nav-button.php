<?php if ( !is_active_sidebar( LAYERS_THEME_SLUG . '-off-canvas-sidebar' ) && !has_nav_menu( LAYERS_THEME_SLUG . '-primary' ) ) return; ?>

<a class="responsive-nav"  data-toggle="#off-canvas-right" data-toggle-class="open">
	<span class="l-menu"></span>
</a>